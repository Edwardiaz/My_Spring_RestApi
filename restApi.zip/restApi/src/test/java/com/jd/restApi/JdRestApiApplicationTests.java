package com.jd.restApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
